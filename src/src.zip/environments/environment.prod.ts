export const environment = {
  production: true,
  apiUrl: "https://testadminapi.groupbenefitz.aitestpro.com",
  corporateClientId:"0"

  // sandbox:
  // apiUrl:"https://api-admin.groupbenefitz.org",
  //  corporateClientId:"0"

  //prod
  // apiUrl:"https://api-admin.groupbenefitz.net",
  // corporateClientId:"0"
};
