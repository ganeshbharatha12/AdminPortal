import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-system-users',
  templateUrl: './manage-system-users.component.html',
  styleUrls: ['./manage-system-users.component.css']
})
export class ManageSystemUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
