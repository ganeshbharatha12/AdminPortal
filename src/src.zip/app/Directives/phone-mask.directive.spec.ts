/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PhoneMaskDirective } from './phone-mask.directive';

describe('Directive: PhoneMask', () => {
  it('should create an instance', () => {
    // const directive = new PhoneMaskDirective();
    // expect(directive).toBeTruthy();
  });
});
