/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { EnableDisableDirective } from './enable-disable.directive';

describe('Directive: EnableDisable', () => {
  it('should create an instance', () => {
    const directive = new EnableDisableDirective();
    expect(directive).toBeTruthy();
  });
});
