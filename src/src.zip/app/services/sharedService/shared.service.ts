import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  public corpData:string

constructor() { }



setCorpData(data){


this.corpData =data
}
getCorpData(){
return this.corpData
}


}
