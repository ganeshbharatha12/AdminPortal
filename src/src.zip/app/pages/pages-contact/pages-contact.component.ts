import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages-contact',
  templateUrl: './pages-contact.component.html',
  styleUrls: ['./pages-contact.component.css']
})
export class PagesContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
