/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FilerenamePipe } from './filerename.pipe';

describe('Pipe: Filerenamee', () => {
  it('create an instance', () => {
    let pipe = new FilerenamePipe();
    expect(pipe).toBeTruthy();
  });
});
