import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'salestrackingcode'
})
export class SalestrackingcodePipe implements PipeTransform {

  transform(value: any, ...args: unknown[]): unknown {

    if(value!=''){
      value=value.replace(/\D/g, '');

    }
    return null;
  }

}
