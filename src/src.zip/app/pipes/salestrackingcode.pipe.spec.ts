import { SalestrackingcodePipe } from './salestrackingcode.pipe';

describe('SalestrackingcodePipe', () => {
  it('create an instance', () => {
    const pipe = new SalestrackingcodePipe();
    expect(pipe).toBeTruthy();
  });
});
